# Persona Pipeline starter

This pack runs a four-step prompt chain. One model answers four times, and each
step carries its own persona, its own temperature, and its own view of the work.

Every decision in it is argued in *The Persona Pipeline: One Model, Four
Personas, and a Rule About Who Sees What*, on the course website under
Tutorials.

## What each file is

| File | What it is |
|---|---|
| `persona_pipeline.py` | The whole program. The orchestration is the for-loop in `run_pipeline()` |
| `ollama_client.py` | `load_config()` and `chat()`, the two functions every script in this course calls |
| `config.json` | Every dial: endpoint, model, seed, logging level, and the four steps |
| `task_brief.md` | The design brief the interviewer step reads |
| `decisions.md` | Your answers to the interviewer's questions, pre-filled so the chain runs first try |
| `.agents/skills/system-prompt-author/SKILL.md` | The skill the author and reviser steps load |

## How do I run it?

Ollama must be listening, and you must have pulled the model. From a container,
the host is `host.docker.internal` rather than `localhost`, so start Ollama so
that it accepts connections from outside the host:

```bash
OLLAMA_CONTEXT_LENGTH=8192 OLLAMA_HOST=0.0.0.0 ollama serve   # in one terminal
ollama pull llama3.2                                          # once
```

Then run the chain from this folder:

```bash
python3 persona_pipeline.py config.json
```

The program prints five things, in this order:

1. the plan, before it runs anything, so you can predict each step's behavior;
2. the four step outputs, in order;
3. a trace table of what each step cost;
4. the final artifact; and
5. the verdict of six checks applied in code.

## How do I change it?

Edit `config.json`, not the code. Four things differ between steps:

- the persona,
- the temperature,
- whether a skill body is present, and
- the `sees` list that decides what the step may read.

That last list is the whole content of an agent system at this scale.

Run these four experiments. Each one is a single edit.

1. Remove `"skill": "system-prompt-author"` from the author step. Compare the two
   candidates, and run the six checks on both.
2. Add `"task"` and `"decisions"` to the red team's `sees` list. Do the attacks get
   sharper, or only more agreeable?
3. Set the red team's temperature to `0.1`. Are the three attacks still three
   different attacks?
4. Edit one line of `decisions.md`, such as the 150-word cap, and see how far that
   single answer propagates.

## What if it fails?

A missing `SKILL.md` stops the run and names the path it looked at. It fails
loudly on purpose, because a pipeline that quietly drops its rules produces
output that looks fine and is not. The directory name must match the skill's
`name:` field exactly.

A connection error names the URL it tried. Check `ollama_url` in `config.json`
against where Ollama is actually listening before you change anything else.
